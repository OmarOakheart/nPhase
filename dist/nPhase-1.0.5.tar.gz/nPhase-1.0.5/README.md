# nPhase
Ploidy agnostic phasing pipeline and algorithm

Please come back soon if you're interested in using nPhase, I'm still checking that everything works as intended on a clean install before uploading the code.

